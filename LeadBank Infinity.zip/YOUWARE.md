# Lead Bank - Professional Banking Portal

## Overview
This is a complete banking administration portal with customer management, transaction processing, and deposit functionality. The application uses Airtable as the backend database and includes photo upload capabilities for customer profiles.

## Core Features
- **Admin Authentication**: Simple login system with persistent sessions
- **Customer Management**: Create, view, edit customers with photo upload support
- **Transaction Processing**: Handle credits, debits, transfers, and loans
- **Deposit System**: Bank transfer and Bitcoin deposit options for customers
- **Dashboard Analytics**: Real-time statistics and data visualization
- **Data Export**: JSON export functionality for backup purposes

## Architecture
- **Frontend**: Vanilla HTML/CSS/JavaScript (no frameworks)
- **Backend**: Airtable API integration for data persistence
- **File Storage**: Base64 encoding for profile photos stored in Airtable
- **Authentication**: localStorage-based session management

## Database Schema (Airtable)
### Customers Table
- Name, Email, Phone (text fields)
- AccountType (Savings/Checking/Business)
- Balance (number)
- Status (Active/Inactive/Pending/Suspended)
- DateCreated (date)
- PhotoUrl (base64 encoded image data)

### Transactions Table
- CustomerId (linked to Customers)
- Type (Credit/Debit/Transfer/Loan)
- Amount (number)
- Description (text)
- Date (date)
- Status (Completed/Pending)

## Key Implementation Details
- **Photo Upload**: Files converted to base64 and stored directly in Airtable
- **Deposit Modal**: Dual-option system with bank transfer details and Bitcoin wallet
- **Real-time Updates**: Dashboard statistics refresh after data modifications
- **Responsive Design**: Mobile-first CSS with grid layouts
- **Error Handling**: User-friendly notifications with auto-dismiss

## API Configuration
The application requires Airtable API credentials:
- Base ID: `app06c6G1MQP5bYhT`
- API Token: Configured in JavaScript (production should use environment variables)
- Tables: `Customers` and `Transactions`

## Deposit Information
- **Bank Transfer**: Derrick Eriyo, Account #214586511579, Routing #101019644
- **Bitcoin Wallet**: 3LqWhxkQo7zcjmhrovzJuvBAEbvT7aqou7

## Development Notes
- All modals use event delegation for dynamic content
- Customer photos fallback to default Lead Bank logo if upload fails
- Base64 storage may hit Airtable field limits with large images
- Authentication is simplified for demo purposes
- Copy-to-clipboard functionality for Bitcoin wallet address