# Lead Bank - Professional Banking Portal

![Lead Bank](https://img.shields.io/badge/Lead%20Bank-Banking%20Portal-6366F1?style=for-the-badge)
![Status](https://img.shields.io/badge/Status-Production%20Ready-success?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-blue?style=for-the-badge)

A professional banking administration portal with comprehensive customer management, transaction processing, and deposit functionality. This single-page application provides financial institutions with powerful tools to manage customer accounts and banking operations.

## Features

- **Admin Authentication** - Secure login system with session persistence
- **Customer Management** - Create, view, edit, and delete customer profiles
- **Transaction Processing** - Handle credits, debits, transfers, and loans
- **Deposit System** - Bank transfer and Bitcoin deposit options
- **Dashboard Analytics** - Real-time statistics and account summaries
- **Data Export** - JSON export functionality for backup purposes
- **Responsive Design** - Mobile-friendly interface

## Technology Stack

- **Frontend**: Vanilla HTML/CSS/JavaScript (no frameworks)
- **Backend**: Supabase for data storage and authentication
- **Image Storage**: Base64 encoding for profile photos
- **Deployment**: Static site (Netlify, Vercel, or GitHub Pages)

## Deployment

This application is ready for deployment on any static hosting service:

1. Clone this repository
2. Deploy the `index.html` file to your hosting service
3. No build process required - it's ready to go!

## Screenshots

*(Add screenshots of your application here)*

## Access

Demo Login:
- Username: `admin`
- Password: `admin123`

## Local Development

1. Clone the repository
2. Open `index.html` in your browser
3. Login with the demo credentials

## License

MIT License - Feel free to use and modify for your own projects!

---

&copy; 2025 Lead Bank. All Rights Reserved.